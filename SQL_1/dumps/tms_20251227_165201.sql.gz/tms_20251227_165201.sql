--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2 (Ubuntu 16.2-1ubuntu4)
-- Dumped by pg_dump version 16.2 (Ubuntu 16.2-1ubuntu4)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: analysis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analysis (
    an_id integer NOT NULL,
    an_name character varying(255),
    an_cost double precision,
    an_price double precision,
    an_group character varying(255)
);


ALTER TABLE public.analysis OWNER TO postgres;

--
-- Name: groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.groups (
    gr_id integer NOT NULL,
    gr_name character varying(255),
    gr_temp double precision
);


ALTER TABLE public.groups OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    ord_id integer NOT NULL,
    ord_datetime date,
    ord_an integer
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Data for Name: analysis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analysis (an_id, an_name, an_cost, an_price, an_group) FROM stdin;
1	analiz1	22	26	group1
2	analiz2	23	29	group2
3	analiz3	21	50	group2
4	analiz4	333	3455	group1
5	analiz5	150	325	group1
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.groups (gr_id, gr_name, gr_temp) FROM stdin;
1	group1	23.5
2	group2	10
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (ord_id, ord_datetime, ord_an) FROM stdin;
1	2020-02-05	5
2	2020-02-06	2
3	2020-02-07	3
4	2020-02-08	1
5	2020-02-10	2
6	2020-02-16	2
7	2020-02-20	3
\.


--
-- Name: analysis analysis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analysis
    ADD CONSTRAINT analysis_pkey PRIMARY KEY (an_id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (gr_id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (ord_id);


--
-- Name: orders analysis_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT analysis_id FOREIGN KEY (ord_an) REFERENCES public.analysis(an_id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO jrdeath;


--
-- PostgreSQL database dump complete
--

